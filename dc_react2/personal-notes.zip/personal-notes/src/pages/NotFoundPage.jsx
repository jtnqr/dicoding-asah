import React from 'react';

function NotFoundPage() {
    return (
        <div>
            <h2>404</h2>
            <p>Halaman tidak ditemukan</p>
        </div>
    );
}

export default NotFoundPage;
